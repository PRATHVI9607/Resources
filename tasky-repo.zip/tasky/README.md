# Tasky

A tiny full-stack to-do app used for a hands-on Docker workshop.

| Part  | Tech                         | Folder  |
|-------|------------------------------|---------|
| web   | React 18 + Vite 8            | `web/`  |
| api   | Node.js 22 + Express         | `api/`  |
| db    | PostgreSQL 16                | (image) |
| cache | Redis 7                      | (image) |

The application code is finished. **There are no Docker files yet.** During the
workshop you write every Dockerfile, the Compose files and the CI workflow
yourself, following `Tasky-Workshop.html`.

## Layout

```
api/
  src/server.js      Express routes, graceful shutdown on SIGTERM
  src/config.js      all settings come from environment variables
  src/db.js          Postgres pool + optional Redis client
  src/migrate.js     applies migrations/*.sql once each
  src/validate.js    input checks (unit tested)
  migrations/        SQL files
  test/              node --test unit tests
web/
  src/App.jsx        the UI
  src/api.js         fetch wrapper, every call goes to /api/...
  vite.config.js     dev server proxies /api to API_URL
```

## API

| Method | Path              | What it does                         |
|--------|-------------------|--------------------------------------|
| GET    | /api/health       | checks db + cache, returns hostname  |
| GET    | /api/tasks        | list tasks (cached in Redis for 30s) |
| POST   | /api/tasks        | `{"title": "..."}` creates a task    |
| PATCH  | /api/tasks/:id    | toggles done                         |
| DELETE | /api/tasks/:id    | deletes                              |

## Configuration (environment variables)

| Variable           | Default         | Used by |
|--------------------|-----------------|---------|
| PORT               | 3000            | api     |
| DB_HOST            | localhost       | api     |
| DB_PORT            | 5432            | api     |
| DB_NAME            | tasky           | api     |
| DB_USER            | tasky           | api     |
| DB_PASSWORD        | tasky           | api     |
| DB_PASSWORD_FILE   | (unset)         | api, read instead of DB_PASSWORD |
| REDIS_URL          | (empty = off)   | api     |
| APP_VERSION        | dev             | api     |
| API_URL            | http://localhost:3000 | web dev server proxy |
| VITE_APP_NAME      | Tasky           | web, baked in at build time |

## Checkpoints

Stuck? The `solution` branch has one tagged commit per workshop checkpoint:

```
git fetch --tags
git tag -l "step-*"
git checkout step-09-compose        # jump to that point (detached HEAD)
git switch main                     # back to your own work
```

## Run without Docker (optional)

Needs Node 20+ and a Postgres you can reach.

```
cd api && npm install && npm run migrate && npm start
cd web && npm install && npm run dev      # http://localhost:5173
```
