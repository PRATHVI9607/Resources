import { readFileSync } from "node:fs";

// NAME_FILE (a mounted secret) wins over a plain NAME env var
function secret(name, fallback) {
  const file = process.env[`${name}_FILE`];
  if (file) return readFileSync(file, "utf8").trim();
  return process.env[name] ?? fallback;
}

export const config = {
  port: Number(process.env.PORT ?? 3000),
  version: process.env.APP_VERSION ?? "dev",
  db: {
    host: process.env.DB_HOST ?? "localhost",
    port: Number(process.env.DB_PORT ?? 5432),
    database: process.env.DB_NAME ?? "tasky",
    user: process.env.DB_USER ?? "tasky",
    password: secret("DB_PASSWORD", "tasky"),
  },
  // empty means "run without a cache"
  redisUrl: process.env.REDIS_URL ?? "",
};
