import pg from "pg";
import { createClient } from "redis";
import { config } from "./config.js";

export const pool = new pg.Pool({ ...config.db, max: 10 });

export const cache = config.redisUrl ? createClient({ url: config.redisUrl }) : null;

if (cache) {
  cache.on("error", (err) => console.error("redis:", err.message));
}
