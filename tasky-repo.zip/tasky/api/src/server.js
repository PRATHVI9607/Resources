import os from "node:os";
import express from "express";
import { config } from "./config.js";
import { cache, pool } from "./db.js";
import { cleanTitle, parseId } from "./validate.js";

const LIST_KEY = "tasks:all";
const COLUMNS = "id, title, done, created_at";

const app = express();
app.use(express.json({ limit: "10kb" }));

async function dropListCache() {
  if (cache?.isReady) await cache.del(LIST_KEY);
}

app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    if (cache) await cache.ping();
    // hostname is the container ID inside Docker, useful when scaling
    res.json({ ok: true, host: os.hostname(), version: config.version, cache: Boolean(cache) });
  } catch (err) {
    res.status(503).json({ ok: false, error: err.message });
  }
});

app.get("/api/tasks", async (req, res, next) => {
  try {
    if (cache?.isReady) {
      const hit = await cache.get(LIST_KEY);
      if (hit) return res.set("x-cache", "hit").json(JSON.parse(hit));
    }
    const { rows } = await pool.query(`SELECT ${COLUMNS} FROM tasks ORDER BY id DESC`);
    if (cache?.isReady) await cache.set(LIST_KEY, JSON.stringify(rows), { EX: 30 });
    res.set("x-cache", "miss").json(rows);
  } catch (err) {
    next(err);
  }
});

app.post("/api/tasks", async (req, res, next) => {
  const title = cleanTitle(req.body?.title);
  if (!title) return res.status(400).json({ error: "title must be 1 to 200 characters" });
  try {
    const { rows } = await pool.query(
      `INSERT INTO tasks (title) VALUES ($1) RETURNING ${COLUMNS}`,
      [title],
    );
    await dropListCache();
    res.status(201).json(rows[0]);
  } catch (err) {
    next(err);
  }
});

app.patch("/api/tasks/:id", async (req, res, next) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: "bad id" });
  try {
    const { rows } = await pool.query(
      `UPDATE tasks SET done = NOT done WHERE id = $1 RETURNING ${COLUMNS}`,
      [id],
    );
    if (rows.length === 0) return res.status(404).json({ error: "not found" });
    await dropListCache();
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
});

app.delete("/api/tasks/:id", async (req, res, next) => {
  const id = parseId(req.params.id);
  if (!id) return res.status(400).json({ error: "bad id" });
  try {
    const { rowCount } = await pool.query("DELETE FROM tasks WHERE id = $1", [id]);
    if (rowCount === 0) return res.status(404).json({ error: "not found" });
    await dropListCache();
    res.status(204).end();
  } catch (err) {
    next(err);
  }
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "internal error" });
});

if (cache) await cache.connect();

// 0.0.0.0, not localhost: inside a container localhost is unreachable from outside
const server = app.listen(config.port, "0.0.0.0", () => {
  console.log(`tasky api ${config.version} listening on :${config.port}`);
});

// docker stop sends SIGTERM; finish in-flight requests, then exit
function shutdown(signal) {
  console.log(`${signal} received, shutting down`);
  server.close(async () => {
    await pool.end();
    if (cache?.isOpen) await cache.quit();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 8000).unref();
}

process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
