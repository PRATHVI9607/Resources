import assert from "node:assert/strict";
import { test } from "node:test";
import { cleanTitle, parseId } from "../src/validate.js";

test("cleanTitle trims and accepts normal titles", () => {
  assert.equal(cleanTitle("  buy milk "), "buy milk");
});

test("cleanTitle rejects empty, huge and non-string values", () => {
  assert.equal(cleanTitle("   "), null);
  assert.equal(cleanTitle("x".repeat(201)), null);
  assert.equal(cleanTitle(42), null);
});

test("parseId only accepts positive integers", () => {
  assert.equal(parseId("7"), 7);
  assert.equal(parseId("0"), null);
  assert.equal(parseId("abc"), null);
  assert.equal(parseId("1.5"), null);
});
