async function request(path, options = {}) {
  const res = await fetch(path, {
    headers: { "content-type": "application/json" },
    ...options,
  });
  if (res.status === 204) return null;
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.error ?? `request failed (${res.status})`);
  return body;
}

export const api = {
  health: () => request("/api/health"),
  list: () => request("/api/tasks"),
  add: (title) => request("/api/tasks", { method: "POST", body: JSON.stringify({ title }) }),
  toggle: (id) => request(`/api/tasks/${id}`, { method: "PATCH" }),
  remove: (id) => request(`/api/tasks/${id}`, { method: "DELETE" }),
};
