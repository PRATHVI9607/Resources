import { useEffect, useState } from "react";
import { api } from "./api.js";

const APP_NAME = import.meta.env.VITE_APP_NAME ?? "Tasky";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [error, setError] = useState("");
  const [server, setServer] = useState(null);

  async function refresh() {
    try {
      setTasks(await api.list());
      setServer(await api.health());
      setError("");
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  async function run(action) {
    try {
      await action();
      await refresh();
    } catch (err) {
      setError(err.message);
    }
  }

  function onSubmit(e) {
    e.preventDefault();
    if (!title.trim()) return;
    run(async () => {
      await api.add(title);
      setTitle("");
    });
  }

  const left = tasks.filter((t) => !t.done).length;

  return (
    <main className="card">
      <header>
        <h1>{APP_NAME}</h1>
        <span className="count">{left} left</span>
      </header>

      <form onSubmit={onSubmit}>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="What needs doing?"
          maxLength={200}
          aria-label="New task"
        />
        <button type="submit">Add</button>
      </form>

      {error && <p className="error">{error}</p>}

      <ul>
        {tasks.map((t) => (
          <li key={t.id} className={t.done ? "done" : ""}>
            <label>
              <input type="checkbox" checked={t.done} onChange={() => run(() => api.toggle(t.id))} />
              <span>{t.title}</span>
            </label>
            <button className="ghost" onClick={() => run(() => api.remove(t.id))} aria-label="Delete">
              ×
            </button>
          </li>
        ))}
        {tasks.length === 0 && !error && <li className="empty">No tasks yet. Add one above.</li>}
      </ul>

      <footer>
        {server ? (
          <>
            served by <code>{server.host}</code> · api {server.version} · cache {server.cache ? "on" : "off"}
          </>
        ) : (
          "connecting to api..."
        )}
        <button className="ghost" onClick={refresh}>refresh</button>
      </footer>
    </main>
  );
}
