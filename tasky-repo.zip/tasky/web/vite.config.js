import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

// In Docker the API is reachable as http://api:3000, on your laptop as localhost
const apiUrl = process.env.API_URL ?? "http://localhost:3000";

export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    strictPort: true, // fail loudly instead of silently moving to 5174
    proxy: {
      "/api": apiUrl,
    },
    // only needed if you bind-mount the source on Windows/macOS instead of using compose watch
    watch: { usePolling: process.env.CHOKIDAR_USEPOLLING === "true" },
  },
});
